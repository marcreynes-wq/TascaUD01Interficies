# Gestió de Lloguer de Videojocs (Projecte Maven NetBeans - DPVI)

Aquest projecte ha estat configurat com un **Projecte Maven de NetBeans** seguint exactament l'estructura reflectida a la captura de pantalla (`dpvi.gestiollogervideojocs`).

## 📁 Estructura del Projecte Maven
- **artifactId**: `GestioLloguerVideojocs`
- **groupId**: `dpvi`
- **Paquet principal**: `dpvi.gestiollogervideojocs`
- **Clau d'entrada (Main Class)**: `dpvi.gestiollogervideojocs.GestioLloguerVideojocs`
- **Llibreria de Validació**: `dpvi.validation.ValidationAPI`
- **Recursos de localització**: `src/main/resources/Bundle_ca.properties`

## 🚀 Com obrir i executar a NetBeans
1. Descomprimeix el fitxer ZIP.
2. A NetBeans IDE, ves a `File` -> `Open Project...` i selecciona la carpeta `GestioLloguerVideojocs`. NetBeans la reconeixerà automàticament com a **Projecte Maven**.
3. Fes clic dret a sobre del projecte i selecciona `Clean and Build`.
4. Prem `F6` o fes clic a `Run` per executar la classe principal `GestioLloguerVideojocs.java`.
