package dpvi.validation;

public class ValidationAPI {
    public static void validarNomMajuscula(String nom) throws ValidationException {
        if (nom == null || nom.trim().isEmpty()) {
            throw new ValidationException("El camp de nom no pot estar buit.");
        }
        char primer = nom.trim().charAt(0);
        if (!Character.isUpperCase(primer)) {
            throw new ValidationException("El nom ha de començar obligatòriament amb lletra majúscula (Ex: Marc).");
        }
    }
}
