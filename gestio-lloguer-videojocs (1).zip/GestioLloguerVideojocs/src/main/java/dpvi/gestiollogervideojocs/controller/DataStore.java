package dpvi.gestiollogervideojocs.controller;

import dpvi.gestiollogervideojocs.model.*;

import java.time.LocalDate;

import java.util.*;

public class DataStore {
    private static DataStore instance;
    private final List<Usuari> usuaris = new ArrayList<>();
    private final List<Joc> jocs = new ArrayList<>();
    private final List<Lloguer> lloguers = new ArrayList<>();
    private int lloguerCounter = 7;

    private DataStore() {
        carregarDadesInicials();
    }

    public static synchronized DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }

    private void carregarDadesInicials() {
        // Usuaris inicials
        Usuari u1 = new Usuari("Marc", "López", "", "12345678A", "600112233", LocalDate.of(2025, 3, 1));
        Usuari u2 = new Usuari("Laura", "García", "", "87654321B", "699887766", LocalDate.of(2025, 3, 5));
        usuaris.add(u1);
        usuaris.add(u2);

        // Jocs inicials amb estoc exactament com a la imatge
        Map<Plataforma, Integer> eCyberpunk = new EnumMap<>(Plataforma.class);
        eCyberpunk.put(Plataforma.PS5, 0);
        eCyberpunk.put(Plataforma.XBOX, 0);
        eCyberpunk.put(Plataforma.PC, 1);
        eCyberpunk.put(Plataforma.SWITCH_2, 1);
        Joc j1 = new Joc("Cyberpunk 2077", "Acció", eCyberpunk);

        Map<Plataforma, Integer> eMinecraft = new EnumMap<>(Plataforma.class);
        eMinecraft.put(Plataforma.PS5, 1);
        eMinecraft.put(Plataforma.XBOX, 2);
        eMinecraft.put(Plataforma.PC, 3);
        eMinecraft.put(Plataforma.SWITCH_2, 1);
        Joc j2 = new Joc("Minecraft", "Aventura", eMinecraft);

        Map<Plataforma, Integer> eFifa = new EnumMap<>(Plataforma.class);
        eFifa.put(Plataforma.PS5, 1);
        eFifa.put(Plataforma.XBOX, 0);
        eFifa.put(Plataforma.PC, 2);
        eFifa.put(Plataforma.SWITCH_2, 0);
        Joc j3 = new Joc("FIFA 25", "Esports", eFifa);

        Map<Plataforma, Integer> eZelda = new EnumMap<>(Plataforma.class);
        eZelda.put(Plataforma.PS5, 2);
        eZelda.put(Plataforma.XBOX, 0);
        eZelda.put(Plataforma.PC, 1);
        eZelda.put(Plataforma.SWITCH_2, 1);
        Joc j4 = new Joc("The Legend of Zelda", "Aventura", eZelda);

        Map<Plataforma, Integer> eCod = new EnumMap<>(Plataforma.class);
        eCod.put(Plataforma.PS5, 1);
        eCod.put(Plataforma.XBOX, 1);
        eCod.put(Plataforma.PC, 2);
        eCod.put(Plataforma.SWITCH_2, 0);
        Joc j5 = new Joc("Call of Duty", "Acció", eCod);

        Map<Plataforma, Integer> eGow = new EnumMap<>(Plataforma.class);
        eGow.put(Plataforma.PS5, 0);
        eGow.put(Plataforma.XBOX, 0);
        eGow.put(Plataforma.PC, 2);
        eGow.put(Plataforma.SWITCH_2, 0);
        Joc j6 = new Joc("God of War", "Acció", eGow);

        jocs.add(j1);
        jocs.add(j2);
        jocs.add(j3);
        jocs.add(j4);
        jocs.add(j5);
        jocs.add(j6);

        // Lloguers inicials (01 a 06 com a la imatge)
        // 01: God of War - Marc López - PC - 28/03/2025 -> 31/03/2025 (Retornat)
        lloguers.add(new Lloguer(1, u1, j6, Plataforma.PC, LocalDate.of(2025, 3, 28), LocalDate.of(2025, 3, 31), true));
        // 02: Call of Duty - Laura García - PS5 - 01/04/2025 -> 04/04/2025 (Retornat)
        lloguers.add(new Lloguer(2, u2, j5, Plataforma.PS5, LocalDate.of(2025, 4, 1), LocalDate.of(2025, 4, 4), true));
        // 03: The Legend of Zelda - Marc López - Switch 2 - 05/04/2025 -> 08/04/2025 (Fora de termini / No retornat)
        lloguers.add(new Lloguer(3, u1, j4, Plataforma.SWITCH_2, LocalDate.of(2025, 4, 5), LocalDate.of(2025, 4, 8), false));
        // 04: FIFA 25 - Laura García - PS5 - 10/04/2025 -> 13/04/2025 (Retornat)
        lloguers.add(new Lloguer(4, u2, j3, Plataforma.PS5, LocalDate.of(2025, 4, 10), LocalDate.of(2025, 4, 13), true));
        // 05: Minecraft - Marc López - Switch 2 - 14/04/2025 -> 17/04/2025 (Retornat)
        lloguers.add(new Lloguer(5, u1, j2, Plataforma.SWITCH_2, LocalDate.of(2025, 4, 14), LocalDate.of(2025, 4, 17), true));
        // 06: Cyberpunk 2077 - Laura García - PC - 15/04/2025 -> 18/04/2025 (Actiu / No retornat)
        lloguers.add(new Lloguer(6, u2, j1, Plataforma.PC, LocalDate.of(2025, 4, 15), LocalDate.of(2025, 4, 18), false));
    }

    public synchronized List<Usuari> getUsuaris() {
        return Collections.unmodifiableList(usuaris);
    }

    public synchronized List<Joc> getJocs() {
        return Collections.unmodifiableList(jocs);
    }

    public synchronized List<Lloguer> getLloguers() {
        return Collections.unmodifiableList(lloguers);
    }

    public synchronized int getProximNumRegistre() {
        return lloguerCounter;
    }

    public synchronized void afegirUsuari(Usuari u) {
        usuaris.add(u);
    }

    public synchronized void afegirJoc(Joc j) {
        jocs.add(j);
    }

    public synchronized Lloguer registrarLloguer(Usuari u, Joc j, Plataforma p) {
        if (j.getEstoc(p) <= 0) {
            throw new IllegalArgumentException("No hi ha unitats disponibles per a la plataforma " + p.getNom());
        }
        j.decrementarEstoc(p);
        LocalDate avui = LocalDate.now();
        LocalDate tornada = avui.plusDays(3);
        Lloguer nou = new Lloguer(lloguerCounter++, u, j, p, avui, tornada, false);
        lloguers.add(nou);
        return nou;
    }

    public synchronized void retornarLloguer(Lloguer l) {
        if (!l.isRetornat()) {
            l.setRetornat(true);
            l.getJoc().incrementarEstoc(l.getPlataforma());
        }
    }

    public synchronized void esborrarUsuari(Usuari u) {
        boolean teLloguersActius = lloguers.stream()
                .anyMatch(l -> l.getUsuari().equals(u) && !l.isRetornat());
        if (teLloguersActius) {
            throw new IllegalStateException("No es pot eliminar l'usuari '" + u.getNomComplet() + "' perquè té lloguers actius pendents de retornar.");
        }
        usuaris.remove(u);
    }

    public synchronized void esborrarJoc(Joc j) {
        boolean teLloguersActius = lloguers.stream()
                .anyMatch(l -> l.getJoc().equals(j) && !l.isRetornat());
        if (teLloguersActius) {
            throw new IllegalStateException("No es pot eliminar el joc '" + j.getTitol() + "' perquè té lloguers actius pendents de retornar.");
        }
        jocs.remove(j);
    }
}
