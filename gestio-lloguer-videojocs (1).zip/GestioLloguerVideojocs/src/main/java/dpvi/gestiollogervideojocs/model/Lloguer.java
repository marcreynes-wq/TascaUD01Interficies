package dpvi.gestiollogervideojocs.model;

import java.time.LocalDate;

public class Lloguer {
    private int numRegistre;
    private Usuari usuari;
    private Joc joc;
    private Plataforma plataforma;
    private LocalDate dataInici;
    private LocalDate dataTornada;
    private boolean retornat;

    public Lloguer(int numRegistre, Usuari usuari, Joc joc, Plataforma plataforma, LocalDate dataInici, LocalDate dataTornada, boolean retornat) {
        this.numRegistre = numRegistre;
        this.usuari = usuari;
        this.joc = joc;
        this.plataforma = plataforma;
        this.dataInici = dataInici;
        this.dataTornada = dataTornada;
        this.retornat = retornat;
    }

    public int getNumRegistre() { return numRegistre; }
    public String getNumRegistreFormattat() { return String.format("%02d", numRegistre); }
    public Usuari getUsuari() { return usuari; }
    public Joc getJoc() { return joc; }
    public Plataforma getPlataforma() { return plataforma; }
    public LocalDate getDataInici() { return dataInici; }
    public LocalDate getDataTornada() { return dataTornada; }
    public boolean isRetornat() { return retornat; }

    public void setRetornat(boolean retornat) {
        this.retornat = retornat;
    }

    public boolean isForaDeTermini() {
        return !retornat && LocalDate.now().isAfter(dataTornada);
    }
}
