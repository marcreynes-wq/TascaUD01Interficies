package dpvi.gestiollogervideojocs.model;

public enum Plataforma {
    PC("PC"),
    PS5("PS5"),
    XBOX("Xbox"),
    SWITCH_2("Switch 2");

    private final String nom;

    Plataforma(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    @Override
    public String toString() {
        return nom;
    }
}
