package dpvi.gestiollogervideojocs.model;

import java.util.EnumMap;
import java.util.Map;

public class Joc {
    private String titol;
    private String genere;
    private Map<Plataforma, Integer> estocPerPlataforma;

    public Joc(String titol, String genere, Map<Plataforma, Integer> estocInitial) {
        this.titol = titol;
        this.genere = genere;
        this.estocPerPlataforma = new EnumMap<>(Plataforma.class);
        for (Plataforma p : Plataforma.values()) {
            this.estocPerPlataforma.put(p, 0);
        }
        if (estocInitial != null) {
            this.estocPerPlataforma.putAll(estocInitial);
        }
    }

    public String getTitol() { return titol; }
    public String getGenere() { return genere; }
    public Map<Plataforma, Integer> getEstocPerPlataforma() { return estocPerPlataforma; }

    public int getEstoc(Plataforma p) {
        return estocPerPlataforma.getOrDefault(p, 0);
    }

    public void setEstoc(Plataforma p, int quantitat) {
        estocPerPlataforma.put(p, quantitat);
    }

    public void decrementarEstoc(Plataforma p) {
        int actual = getEstoc(p);
        if (actual > 0) {
            estocPerPlataforma.put(p, actual - 1);
        }
    }

    public void incrementarEstoc(Plataforma p) {
        int actual = getEstoc(p);
        estocPerPlataforma.put(p, actual + 1);
    }

    @Override
    public String toString() {
        return titol;
    }
}
