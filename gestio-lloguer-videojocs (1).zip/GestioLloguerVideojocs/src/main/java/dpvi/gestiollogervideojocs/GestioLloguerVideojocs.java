package dpvi.gestiollogervideojocs;

import dpvi.gestiollogervideojocs.view.FinestraPrincipal;

import javax.swing.*;
import java.util.Locale;

public class GestioLloguerVideojocs {
    public static void main(String[] args) {
        // Configuració del locale en català
        Locale.setDefault(new Locale("ca", "ES"));

        // Configuració de Look and Feel del sistema
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            FinestraPrincipal fp = new FinestraPrincipal();
            fp.setVisible(true);
        });
    }
}
