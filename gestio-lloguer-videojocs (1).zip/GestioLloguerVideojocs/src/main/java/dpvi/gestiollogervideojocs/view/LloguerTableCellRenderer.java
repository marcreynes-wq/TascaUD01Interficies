package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.Lloguer;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class LloguerTableCellRenderer extends DefaultTableCellRenderer {

    private final Color colorVerd = new Color(212, 248, 212); // #D4F8D4
    private final Color colorVermell = new Color(253, 216, 216); // #FDD8D8

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus, int row, int column) {

        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        // Obtenir el número de registre de la primera columna
        Object numObj = table.getValueAt(row, 0);
        if (numObj != null) {
            String numStr = numObj.toString();
            try {
                int numReg = Integer.parseInt(numStr);
                Lloguer lloguer = DataStore.getInstance().getLloguers().stream()
                        .filter(l -> l.getNumRegistre() == numReg)
                        .findFirst().orElse(null);

                if (lloguer != null) {
                    if (lloguer.isForaDeTermini()) {
                        c.setBackground(isSelected ? colorVermell.darker() : colorVermell);
                        c.setForeground(Color.BLACK);
                    } else {
                        c.setBackground(isSelected ? colorVerd.darker() : colorVerd);
                        c.setForeground(Color.BLACK);
                    }
                }
            } catch (NumberFormatException ignored) {}
        }
        return c;
    }
}
