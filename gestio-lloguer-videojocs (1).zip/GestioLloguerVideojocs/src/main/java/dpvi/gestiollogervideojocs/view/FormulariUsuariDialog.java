package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.Usuari;
import dpvi.validation.ValidationAPI;
import dpvi.validation.ValidationException;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class FormulariUsuariDialog extends JDialog {

    private JTextField txtNom;
    private JTextField txtLlinatge1;
    private JTextField txtLlinatge2;
    private JTextField txtDni;
    private JTextField txtTelefon;
    private JTextField txtDataRegistre;

    private FinestraPrincipal parent;

    public FormulariUsuariDialog(FinestraPrincipal parent) {
        super(parent, "Crear usuari", true);
        this.parent = parent;
        initComponents();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        txtNom = new JTextField();
        txtLlinatge1 = new JTextField();
        txtLlinatge2 = new JTextField();
        txtDni = new JTextField();
        txtTelefon = new JTextField();

        LocalDate avui = LocalDate.now();
        txtDataRegistre = new JTextField(avui.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        txtDataRegistre.setEditable(false);

        formPanel.add(new JLabel("Nom *:"));
        formPanel.add(txtNom);
        formPanel.add(new JLabel("Llinatge 1 *:"));
        formPanel.add(txtLlinatge1);
        formPanel.add(new JLabel("Llinatge 2 *:"));
        formPanel.add(txtLlinatge2);
        formPanel.add(new JLabel("DNI *:"));
        formPanel.add(txtDni);
        formPanel.add(new JLabel("Telèfon *:"));
        formPanel.add(txtTelefon);
        formPanel.add(new JLabel("Data de registre:"));
        formPanel.add(txtDataRegistre);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton btnConfirmar = new JButton("✓ Confirmar");
        btnConfirmar.setBackground(new Color(40, 167, 69));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.addActionListener(e -> guardarUsuari());

        JButton btnCancelar = new JButton("✕ Cancel·lar");
        btnCancelar.addActionListener(e -> dispose());

        btnPanel.add(btnConfirmar);
        btnPanel.add(btnCancelar);

        add(formPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void guardarUsuari() {
        String nom = txtNom.getText();
        String llinatge1 = txtLlinatge1.getText();
        String llinatge2 = txtLlinatge2.getText();
        String dni = txtDni.getText();
        String telefon = txtTelefon.getText();

        try {
            ValidationAPI.validarNomMajuscula(nom);
            ValidationAPI.validarNomMajuscula(llinatge1);
            if (!llinatge2.trim().isEmpty()) {
                ValidationAPI.validarNomMajuscula(llinatge2);
            }

            if (nom.trim().isEmpty() || llinatge1.trim().isEmpty() || dni.trim().isEmpty() || telefon.trim().isEmpty()) {
                throw new ValidationException("Tots els camps marcats amb * són obligatoris.");
            }

            Usuari nou = new Usuari(nom.trim(), llinatge1.trim(), llinatge2.trim(), dni.trim(), telefon.trim(), LocalDate.now());
            DataStore.getInstance().afegirUsuari(nou);

            JOptionPane.showMessageDialog(this, "Usuari creat amb èxit!", "Èxit", JOptionPane.INFORMATION_MESSAGE);
            parent.actualitzarTaula();
            dispose();

        } catch (ValidationException ex) {
            JOptionPane.showMessageDialog(this, "Error de validació amb ValidationAPI:\n" + ex.getMessage(),
                    "Error de Validació", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
