package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.Lloguer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class FinestraTornarLloguerDialog extends JDialog {

    private JTable tableLloguersActius;
    private DefaultTableModel tableModel;
    private JLabel lblJoc;
    private JLabel lblUsuari;
    private JLabel lblPlataforma;
    private JLabel lblDataInici;
    private JButton btnMarcarRetornat;
    private FinestraPrincipal parent;
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public FinestraTornarLloguerDialog(FinestraPrincipal parent) {
        super(parent, "Tornar lloguer", true);
        this.parent = parent;
        initComponents();
        carregarLloguersActius();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        String[] columns = {"Núm. registre", "Títol del joc", "Usuari", "Plataforma", "Data d'inici"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        tableLloguersActius = new JTable(tableModel);
        tableLloguersActius.setRowHeight(24);
        tableLloguersActius.getSelectionModel().addListSelectionListener(e -> actualitzarDetalls());

        JScrollPane scroll = new JScrollPane(tableLloguersActius);
        scroll.setPreferredSize(new Dimension(580, 180));

        // Panel de detalls inferior (com a la imatge 5)
        JPanel detailPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        detailPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        lblJoc = new JLabel("-");
        lblUsuari = new JLabel("-");
        lblPlataforma = new JLabel("-");
        lblDataInici = new JLabel("-");

        detailPanel.add(new JLabel("Joc:"));
        detailPanel.add(lblJoc);
        detailPanel.add(new JLabel("Usuari:"));
        detailPanel.add(lblUsuari);
        detailPanel.add(new JLabel("Plataforma:"));
        detailPanel.add(lblPlataforma);
        detailPanel.add(new JLabel("Data d'inici:"));
        detailPanel.add(lblDataInici);

        // Botons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnMarcarRetornat = new JButton("🔄 Marcar com a retornat");
        btnMarcarRetornat.setBackground(new Color(40, 167, 69));
        btnMarcarRetornat.setForeground(Color.WHITE);
        btnMarcarRetornat.setFocusPainted(false);
        btnMarcarRetornat.setEnabled(false);
        btnMarcarRetornat.addActionListener(e -> processarDevolucio());

        JButton btnTancar = new JButton("✕ Tancar");
        btnTancar.addActionListener(e -> dispose());

        btnPanel.add(btnMarcarRetornat);
        btnPanel.add(btnTancar);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        centerPanel.add(scroll, BorderLayout.CENTER);
        centerPanel.add(detailPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void carregarLloguersActius() {
        tableModel.setRowCount(0);
        List<Lloguer> actius = DataStore.getInstance().getLloguers().stream()
                .filter(l -> !l.isRetornat())
                .sorted((a, b) -> Integer.compare(b.getNumRegistre(), a.getNumRegistre()))
                .collect(Collectors.toList());

        for (Lloguer l : actius) {
            tableModel.addRow(new Object[]{
                    l.getNumRegistreFormattat(),
                    l.getJoc().getTitol(),
                    l.getUsuari().getNomComplet(),
                    l.getPlataforma().getNom(),
                    l.getDataInici().format(dtf)
            });
        }
    }

    private void actualitzarDetalls() {
        int selectedRow = tableLloguersActius.getSelectedRow();
        if (selectedRow >= 0) {
            String numRegStr = (String) tableModel.getValueAt(selectedRow, 0);
            try {
                int numReg = Integer.parseInt(numRegStr);
                Lloguer l = DataStore.getInstance().getLloguers().stream()
                        .filter(x -> x.getNumRegistre() == numReg)
                        .findFirst().orElse(null);

                if (l != null) {
                    lblJoc.setText(l.getJoc().getTitol());
                    lblUsuari.setText(l.getUsuari().getNomComplet());
                    lblPlataforma.setText(l.getPlataforma().getNom());
                    lblDataInici.setText(l.getDataInici().format(dtf));
                    btnMarcarRetornat.setEnabled(true);
                }
            } catch (NumberFormatException ignored) {}
        } else {
            lblJoc.setText("-");
            lblUsuari.setText("-");
            lblPlataforma.setText("-");
            lblDataInici.setText("-");
            btnMarcarRetornat.setEnabled(false);
        }
    }

    private void processarDevolucio() {
        int selectedRow = tableLloguersActius.getSelectedRow();
        if (selectedRow >= 0) {
            String numRegStr = (String) tableModel.getValueAt(selectedRow, 0);
            try {
                int numReg = Integer.parseInt(numRegStr);
                Lloguer l = DataStore.getInstance().getLloguers().stream()
                        .filter(x -> x.getNumRegistre() == numReg)
                        .findFirst().orElse(null);

                if (l != null) {
                    DataStore.getInstance().retornarLloguer(l);
                    JOptionPane.showMessageDialog(this, "Lloguer marcat com a retornat amb èxit!", "Devolució Completada", JOptionPane.INFORMATION_MESSAGE);
                    carregarLloguersActius();
                    parent.actualitzarTaula();
                    actualitzarDetalls();
                }
            } catch (NumberFormatException ignored) {}
        }
    }
}
