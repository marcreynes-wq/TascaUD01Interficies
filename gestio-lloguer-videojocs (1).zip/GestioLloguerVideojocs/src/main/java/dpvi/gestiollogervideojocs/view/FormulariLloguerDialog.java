package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.EnumMap;
import java.util.Map;

public class FormulariLloguerDialog extends JDialog {

    private JTextField txtNumRegistre;
    private JComboBox<Usuari> comboUsuari;
    private JComboBox<Joc> comboJoc;
    private JTextField txtDataInici;
    private JTextField txtDataTornada;

    private Map<Plataforma, JRadioButton> radioPlataformes;
    private ButtonGroup groupPlataformes;

    private JLabel lblGenere;
    private JLabel lblUnitatsPs5;
    private JLabel lblUnitatsXbox;
    private JLabel lblUnitatsPc;
    private JLabel lblUnitatsSwitch;

    private JButton btnConfirmar;
    private JButton btnCancelar;

    private FinestraPrincipal parent;
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public FormulariLloguerDialog(FinestraPrincipal parent) {
        super(parent, "Registrar lloguer", true);
        this.parent = parent;
        initComponents();
        actualitzarPlataformesIInfo();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel mainPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 10, 15));

        // --- PANEL ESQUERRA: Dades del lloguer ---
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createTitledBorder("Dades del lloguer"));

        txtNumRegistre = new JTextField(String.format("%02d", DataStore.getInstance().getProximNumRegistre()));
        txtNumRegistre.setEditable(false);
        txtNumRegistre.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        comboUsuari = new JComboBox<>();
        for (Usuari u : DataStore.getInstance().getUsuaris()) {
            comboUsuari.addItem(u);
        }
        comboUsuari.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        JPanel userPanel = new JPanel(new BorderLayout(5, 0));
        userPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        userPanel.add(comboUsuari, BorderLayout.CENTER);
        JButton btnSelUser = new JButton("Seleccionar...");
        userPanel.add(btnSelUser, BorderLayout.EAST);

        comboJoc = new JComboBox<>();
        for (Joc j : DataStore.getInstance().getJocs()) {
            comboJoc.addItem(j);
        }
        comboJoc.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        comboJoc.addActionListener(e -> actualitzarPlataformesIInfo());

        JPanel jocPanel = new JPanel(new BorderLayout(5, 0));
        jocPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        jocPanel.add(comboJoc, BorderLayout.CENTER);
        JButton btnSelJoc = new JButton("Seleccionar...");
        jocPanel.add(btnSelJoc, BorderLayout.EAST);

        LocalDate avui = LocalDate.now();
        txtDataInici = new JTextField(avui.format(dtf));
        txtDataInici.setEditable(false);
        txtDataInici.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        txtDataTornada = new JTextField(avui.plusDays(3).format(dtf));
        txtDataTornada.setEditable(false);
        txtDataTornada.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        leftPanel.add(createLabel("Núm. de registre:"));
        leftPanel.add(txtNumRegistre);
        leftPanel.add(Box.createVerticalStrut(8));

        leftPanel.add(createLabel("Usuari:"));
        leftPanel.add(userPanel);
        leftPanel.add(Box.createVerticalStrut(8));

        leftPanel.add(createLabel("Joc elegit:"));
        leftPanel.add(jocPanel);
        leftPanel.add(Box.createVerticalStrut(8));

        leftPanel.add(createLabel("Data d'inici:"));
        leftPanel.add(txtDataInici);
        leftPanel.add(Box.createVerticalStrut(8));

        leftPanel.add(createLabel("Data de tornada:"));
        leftPanel.add(txtDataTornada);

        // --- PANEL DRET: Plataforma i Informació del joc ---
        JPanel rightContainer = new JPanel(new GridLayout(2, 1, 10, 10));

        // 1. Panel Plataforma
        JPanel platPanel = new JPanel();
        platPanel.setLayout(new BoxLayout(platPanel, BoxLayout.Y_AXIS));
        platPanel.setBorder(BorderFactory.createTitledBorder("Plataforma"));

        groupPlataformes = new ButtonGroup();
        radioPlataformes = new EnumMap<>(Plataforma.class);

        for (Plataforma p : Plataforma.values()) {
            JRadioButton rb = new JRadioButton(p.getNom());
            radioPlataformes.put(p, rb);
            groupPlataformes.add(rb);
            platPanel.add(rb);
            platPanel.add(Box.createVerticalStrut(4));
        }

        // 2. Panel Informació del joc
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Informació del joc"));

        lblGenere = new JLabel("Gènere: Acció");
        JLabel lblHeaderUnitats = new JLabel("Unitats disponibles:");

        lblUnitatsPs5 = new JLabel("  PS5: 0");
        lblUnitatsXbox = new JLabel("  Xbox: 0");
        lblUnitatsPc = new JLabel("  PC: 0");
        lblUnitatsSwitch = new JLabel("  Switch 2: 0");

        infoPanel.add(lblGenere);
        infoPanel.add(Box.createVerticalStrut(5));
        infoPanel.add(lblHeaderUnitats);
        infoPanel.add(lblUnitatsPs5);
        infoPanel.add(lblUnitatsXbox);
        infoPanel.add(lblUnitatsPc);
        infoPanel.add(lblUnitatsSwitch);

        rightContainer.add(platPanel);
        rightContainer.add(infoPanel);

        mainPanel.add(leftPanel);
        mainPanel.add(rightContainer);

        // --- BOTONS INFERIORS ---
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnConfirmar = new JButton("✓ Confirmar");
        btnConfirmar.setBackground(new Color(40, 167, 69));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.addActionListener(e -> confirmarLloguer());

        btnCancelar = new JButton("✕ Cancel·lar");
        btnCancelar.addActionListener(e -> dispose());

        btnPanel.add(btnConfirmar);
        btnPanel.add(btnCancelar);

        add(mainPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private void actualitzarPlataformesIInfo() {
        Joc jocSeleccionat = (Joc) comboJoc.getSelectedItem();
        if (jocSeleccionat == null) return;

        lblGenere.setText("Gènere: " + jocSeleccionat.getGenere());

        int ps5Estoc = jocSeleccionat.getEstoc(Plataforma.PS5);
        int xboxEstoc = jocSeleccionat.getEstoc(Plataforma.XBOX);
        int pcEstoc = jocSeleccionat.getEstoc(Plataforma.PC);
        int switchEstoc = jocSeleccionat.getEstoc(Plataforma.SWITCH_2);

        lblUnitatsPs5.setText("  PS5: " + ps5Estoc);
        lblUnitatsXbox.setText("  Xbox: " + xboxEstoc);
        lblUnitatsPc.setText("  PC: " + pcEstoc);
        lblUnitatsSwitch.setText("  Switch 2: " + switchEstoc);

        groupPlataformes.clearSelection();
        boolean algunHabilitat = false;

        for (Plataforma p : Plataforma.values()) {
            int estoc = jocSeleccionat.getEstoc(p);
            JRadioButton rb = radioPlataformes.get(p);

            String textUnits = estoc == 1 ? "1 unitat disponible" : estoc + " unitats disponibles";
            rb.setText(p.getNom() + "  (" + textUnits + ")");

            if (estoc > 0) {
                rb.setEnabled(true);
                if (!algunHabilitat) {
                    rb.setSelected(true);
                    algunHabilitat = true;
                }
            } else {
                rb.setEnabled(false);
            }
        }

        btnConfirmar.setEnabled(algunHabilitat);
    }

    private void confirmarLloguer() {
        Usuari usuari = (Usuari) comboUsuari.getSelectedItem();
        Joc joc = (Joc) comboJoc.getSelectedItem();

        Plataforma plataformaSeleccionada = null;
        for (Map.Entry<Plataforma, JRadioButton> entry : radioPlataformes.entrySet()) {
            if (entry.getValue().isSelected() && entry.getValue().isEnabled()) {
                plataformaSeleccionada = entry.getKey();
                break;
            }
        }

        if (usuari == null || joc == null || plataformaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Selecciona una plataforma disponible.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            DataStore.getInstance().registrarLloguer(usuari, joc, plataformaSeleccionada);
            JOptionPane.showMessageDialog(this, "Lloguer registrat amb èxit!", "Èxit", JOptionPane.INFORMATION_MESSAGE);
            parent.actualitzarTaula();
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
