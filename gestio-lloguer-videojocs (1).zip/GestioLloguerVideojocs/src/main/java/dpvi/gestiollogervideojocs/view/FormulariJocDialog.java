package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.Joc;
import dpvi.gestiollogervideojocs.model.Plataforma;
import dpvi.validation.ValidationAPI;
import dpvi.validation.ValidationException;

import javax.swing.*;
import java.awt.*;
import java.util.EnumMap;
import java.util.Map;

public class FormulariJocDialog extends JDialog {

    private JTextField txtTitol;
    private JComboBox<String> comboGenere;
    private Map<Plataforma, JCheckBox> checkPlataformes;
    private Map<Plataforma, JSpinner> spinnerUnitats;

    private FinestraPrincipal parent;

    public FormulariJocDialog(FinestraPrincipal parent) {
        super(parent, "Crear joc", true);
        this.parent = parent;
        initComponents();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Top Panel: Nom i Gènere
        JPanel topPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 5, 15));

        JPanel namePanel = new JPanel(new BorderLayout(5, 0));
        namePanel.add(new JLabel("Nom *: "), BorderLayout.WEST);
        txtTitol = new JTextField();
        namePanel.add(txtTitol, BorderLayout.CENTER);

        JPanel genrePanel = new JPanel(new BorderLayout(5, 0));
        genrePanel.add(new JLabel("Gènere *: "), BorderLayout.WEST);
        comboGenere = new JComboBox<>(new String[]{"Acció", "Aventura", "Esports", "RPG", "Estratègia"});
        genrePanel.add(comboGenere, BorderLayout.CENTER);

        topPanel.add(namePanel);
        topPanel.add(genrePanel);

        // Middle Panel: Plataformes disponibles
        JPanel platPanel = new JPanel(new GridLayout(4, 3, 10, 10));
        platPanel.setBorder(BorderFactory.createTitledBorder("Plataformes disponibles"));

        checkPlataformes = new EnumMap<>(Plataforma.class);
        spinnerUnitats = new EnumMap<>(Plataforma.class);

        for (Plataforma p : Plataforma.values()) {
            JCheckBox chk = new JCheckBox(p.getNom());
            JSpinner spin = new JSpinner(new SpinnerNumberModel(0, 0, 99, 1));
            spin.setEnabled(false);

            chk.addActionListener(e -> {
                spin.setEnabled(chk.isSelected());
                if (!chk.isSelected()) {
                    spin.setValue(0);
                } else if ((int) spin.getValue() == 0) {
                    spin.setValue(1);
                }
            });

            checkPlataformes.put(p, chk);
            spinnerUnitats.put(p, spin);

            platPanel.add(chk);
            platPanel.add(new JLabel("Unitats:", SwingConstants.RIGHT));
            platPanel.add(spin);
        }

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 15, 10, 15));
        centerPanel.add(platPanel, BorderLayout.CENTER);

        // Bottom Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton btnConfirmar = new JButton("✓ Confirmar");
        btnConfirmar.setBackground(new Color(40, 167, 69));
        btnConfirmar.setForeground(Color.WHITE);
        btnConfirmar.setFocusPainted(false);
        btnConfirmar.addActionListener(e -> guardarJoc());

        JButton btnCancelar = new JButton("✕ Cancel·lar");
        btnCancelar.addActionListener(e -> dispose());

        btnPanel.add(btnConfirmar);
        btnPanel.add(btnCancelar);

        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }

    private void guardarJoc() {
        String titol = txtTitol.getText();
        String genere = (String) comboGenere.getSelectedItem();

        try {
            ValidationAPI.validarNomMajuscula(titol);

            Map<Plataforma, Integer> estocMap = new EnumMap<>(Plataforma.class);
            for (Plataforma p : Plataforma.values()) {
                if (checkPlataformes.get(p).isSelected()) {
                    int val = (int) spinnerUnitats.get(p).getValue();
                    estocMap.put(p, val);
                } else {
                    estocMap.put(p, 0);
                }
            }

            Joc nouJoc = new Joc(titol.trim(), genere, estocMap);
            DataStore.getInstance().afegirJoc(nouJoc);

            JOptionPane.showMessageDialog(this, "Joc creat amb èxit!", "Èxit", JOptionPane.INFORMATION_MESSAGE);
            parent.actualitzarTaula();
            dispose();

        } catch (ValidationException ex) {
            JOptionPane.showMessageDialog(this, "Error de validació:\n" + ex.getMessage(), "Error de Validació", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
