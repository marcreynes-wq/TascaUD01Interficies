package dpvi.gestiollogervideojocs.view;

import dpvi.gestiollogervideojocs.controller.DataStore;
import dpvi.gestiollogervideojocs.model.Joc;
import dpvi.gestiollogervideojocs.model.Lloguer;
import dpvi.gestiollogervideojocs.model.Usuari;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class FinestraPrincipal extends JFrame {

    private JTable tableLloguers;
    private DefaultTableModel tableModel;
    private JLabel lblTotal;
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public FinestraPrincipal() {
        super("Gestió de Lloguer de Videojocs");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 500));
        initComponents();
        actualitzarTaula();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        // Barra de Menús
        JMenuBar menuBar = new JMenuBar();

        // Menú Lloguer
        JMenu menuLloguer = new JMenu("Lloguer");
        JMenuItem itemRegistrarLloguer = new JMenuItem("Registrar...");
        JMenuItem itemTornarLloguer = new JMenuItem("Tornar...");

        itemRegistrarLloguer.addActionListener(e -> obrirFormulariLloguer());
        itemTornarLloguer.addActionListener(e -> obrirFinestraTornar());

        menuLloguer.add(itemRegistrarLloguer);
        menuLloguer.add(itemTornarLloguer);

        // Menú Usuari
        JMenu menuUsuari = new JMenu("Usuari");
        JMenuItem itemCrearUsuari = new JMenuItem("Crear...");
        JMenuItem itemBorrarUsuari = new JMenuItem("Borrar...");

        itemCrearUsuari.addActionListener(e -> obrirFormulariUsuari());
        itemBorrarUsuari.addActionListener(e -> esborrarUsuariSeleccionat());

        menuUsuari.add(itemCrearUsuari);
        menuUsuari.add(itemBorrarUsuari);

        // Menú Joc
        JMenu menuJoc = new JMenu("Joc");
        JMenuItem itemCrearJoc = new JMenuItem("Crear...");
        JMenuItem itemBorrarJoc = new JMenuItem("Borrar...");

        itemCrearJoc.addActionListener(e -> obrirFormulariJoc());
        itemBorrarJoc.addActionListener(e -> esborrarJocSeleccionat());

        menuJoc.add(itemCrearJoc);
        menuJoc.add(itemBorrarJoc);

        menuBar.add(menuLloguer);
        menuBar.add(menuUsuari);
        menuBar.add(menuJoc);
        setJMenuBar(menuBar);

        // Columnes exactes segons la imatge (Screen 1)
        String[] columnes = {
                "Núm. registre", "Títol del joc", "Usuari que l'ha llogat",
                "Plataforma", "Data d'inici", "Data de tornada", "Gènere"
        };

        tableModel = new DefaultTableModel(columnes, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableLloguers = new JTable(tableModel);
        tableLloguers.setRowHeight(26);
        tableLloguers.setFont(new Font("SansSerif", Font.PLAIN, 13));

        // Assignar el Renderer de colors
        LloguerTableCellRenderer renderer = new LloguerTableCellRenderer();
        for (int i = 0; i < tableLloguers.getColumnCount(); i++) {
            tableLloguers.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(tableLloguers);

        // Barra d'estat inferior (Total de lloguers: X)
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lblTotal = new JLabel("Total de lloguers: 0");
        lblTotal.setFont(new Font("SansSerif", Font.PLAIN, 12));
        statusPanel.add(lblTotal);

        add(scrollPane, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);
    }

    public void actualitzarTaula() {
        tableModel.setRowCount(0);
        List<Lloguer> lloguers = DataStore.getInstance().getLloguers().stream()
                .sorted((a, b) -> Integer.compare(b.getNumRegistre(), a.getNumRegistre()))
                .collect(Collectors.toList());

        for (Lloguer l : lloguers) {
            tableModel.addRow(new Object[]{
                    l.getNumRegistreFormattat(),
                    l.getJoc().getTitol(),
                    l.getUsuari().getNomComplet(),
                    l.getPlataforma().getNom(),
                    l.getDataInici().format(dtf),
                    l.getDataTornada().format(dtf),
                    l.getJoc().getGenere()
            });
        }

        lblTotal.setText("Total de lloguers: " + lloguers.size());
    }

    private void obrirFormulariLloguer() {
        new FormulariLloguerDialog(this).setVisible(true);
    }

    private void obrirFinestraTornar() {
        new FinestraTornarLloguerDialog(this).setVisible(true);
    }

    private void obrirFormulariUsuari() {
        new FormulariUsuariDialog(this).setVisible(true);
    }

    private void obrirFormulariJoc() {
        new FormulariJocDialog(this).setVisible(true);
    }

    private void esborrarUsuariSeleccionat() {
        List<Usuari> usuaris = DataStore.getInstance().getUsuaris();
        if (usuaris.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hi ha cap usuari registrat.", "Informació", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Usuari seleccionat = (Usuari) JOptionPane.showInputDialog(
                this,
                "Selecciona l'usuari que vols eliminar:",
                "Borrar Usuari",
                JOptionPane.QUESTION_MESSAGE,
                null,
                usuaris.toArray(),
                usuaris.get(0)
        );

        if (seleccionat != null) {
            try {
                DataStore.getInstance().esborrarUsuari(seleccionat);
                JOptionPane.showMessageDialog(this, "Usuari eliminat amb èxit.", "Èxit", JOptionPane.INFORMATION_MESSAGE);
                actualitzarTaula();
            } catch (IllegalStateException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Integritat Referencial", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void esborrarJocSeleccionat() {
        List<Joc> jocs = DataStore.getInstance().getJocs();
        if (jocs.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hi ha cap joc registrat.", "Informació", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Joc seleccionat = (Joc) JOptionPane.showInputDialog(
                this,
                "Selecciona el joc que vols eliminar:",
                "Borrar Joc",
                JOptionPane.QUESTION_MESSAGE,
                null,
                jocs.toArray(),
                jocs.get(0)
        );

        if (seleccionat != null) {
            try {
                DataStore.getInstance().esborrarJoc(seleccionat);
                JOptionPane.showMessageDialog(this, "Joc eliminat amb èxit.", "Èxit", JOptionPane.INFORMATION_MESSAGE);
                actualitzarTaula();
            } catch (IllegalStateException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Integritat Referencial", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}
